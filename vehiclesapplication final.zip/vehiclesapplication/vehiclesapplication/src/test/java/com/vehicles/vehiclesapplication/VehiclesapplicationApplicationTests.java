package com.vehicles.vehiclesapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehiclesapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
